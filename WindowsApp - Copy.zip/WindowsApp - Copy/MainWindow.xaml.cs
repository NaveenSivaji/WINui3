using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using WindowsApp.Views;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace WindowsApp
{
    /// <summary>
    /// An empty window that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainWindow : Window
    {
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr LoadImage(IntPtr hInst, string lpszName, uint uType, int cxDesired, int cyDesired, uint fuLoad);

        private const uint WM_SETICON = 0x0080;
        private const int ICON_SMALL = 0; // Small icon (e.g., title bar)
        private const int ICON_BIG = 1;   // Large icon (e.g., taskbar)
        private const uint IMAGE_ICON = 1;
        private const uint LR_LOADFROMFILE = 0x00000010;
        public MainWindow()
        {
            this.InitializeComponent();
            this.Title = "SNAPdpl";
            // Set the window icon
            SetWindowIcon("D:\\01MainApplcation\\WindowsApp\\Assets\\AppIcon.ico");
            MainFrame.Navigate(typeof(Login));
        }

        private void SetWindowIcon(string iconPath)
        {
            // Get the window handle for the current WinUI 3 window
            IntPtr hWnd = WinRT.Interop.WindowNative.GetWindowHandle(this);

            // Load the icon from file
            IntPtr hIcon = LoadImage(IntPtr.Zero, iconPath, IMAGE_ICON, 0, 0, LR_LOADFROMFILE);

            if (hIcon != IntPtr.Zero)
            {
                // Set the small icon (title bar)
                SendMessage(hWnd, WM_SETICON, (IntPtr)ICON_SMALL, hIcon);

                // Set the large icon (taskbar)
                SendMessage(hWnd, WM_SETICON, (IntPtr)ICON_BIG, hIcon);
            }
        }

    }
}
