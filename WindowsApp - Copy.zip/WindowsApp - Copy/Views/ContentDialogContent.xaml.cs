using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace WindowsApp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ContentDialogContent : Page
    {
        // Event to notify the parent when the popup needs to be closed
        public event Action ClosePopupRequested;
        public ContentDialogContent()
        {
            this.InitializeComponent();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Trigger the close popup event
            ClosePopupRequested?.Invoke();
        }

        private void ContinueButton_Click(object sender, RoutedEventArgs e)
        {
            string origination = (OriginationComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "None";
            string application = (ApplicationComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "None";
            string option = SignInRadioButton.IsChecked == true ? "Sign In" : "Register";

            // Example: Display the values in a dialog
            var dialog = new ContentDialog
            {
                Title = "Selections",
                Content = $"Origination: {origination}\nApplication: {application}\nOption: {option}",
                CloseButtonText = "OK"
            };

            _ = dialog.ShowAsync();

            // Trigger the close popup event
            ClosePopupRequested?.Invoke();
        }
    }
}
