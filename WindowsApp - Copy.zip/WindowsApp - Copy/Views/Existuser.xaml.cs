using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace WindowsApp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Existuser : Page
    {
        public Existuser()
        {
            this.InitializeComponent();
            // Apply a ThemeShadow to the Border
            var themeShadow = new ThemeShadow();
            LoginCard.Shadow = themeShadow;

            // Set the Grid as the shadow host
            LoginCard.Translation = new System.Numerics.Vector3(0, 0, 32);
            LoadUserData();
        }
        private async void LoadUserData()
        {
            try
            {
                // Path to the JSON file
                string filePath = @"D:\2024 Target_Projects_Pocs\User.JSON.JSON";

                // Load JSON data from the file
                string jsonData = await LoadJsonFromFileAsync(filePath);

                // Deserialize JSON data to a list of strings
                var users = JsonSerializer.Deserialize<List<string>>(jsonData);

                // Bind the data to the ListView
                UserListView.ItemsSource = users;
            }
            catch (Exception ex)
            {
                // Handle errors (e.g., file not found or JSON parsing issues)
                var dialog = new ContentDialog
                {
                    Title = "Error",
                    Content = $"Failed to load user data: {ex.Message}",
                    CloseButtonText = "OK"
                };
                _ = dialog.ShowAsync();
            }
        }

        private async Task<string> LoadJsonFromFileAsync(string filePath)
        {
            // Ensure the file exists
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("The JSON file was not found.", filePath);
            }

            // Read the file content
            using (var reader = new StreamReader(filePath))
            {
                return await reader.ReadToEndAsync();
            }
        }

        private void UserListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            // Handle user selection
            var selectedUser = e.ClickedItem as string;
            var dialog = new ContentDialog
            {
                Title = "User Selected",
                Content = $"You selected: {selectedUser}",
                CloseButtonText = "OK"
            };
            _ = dialog.ShowAsync();
        }

        private void ToggleThemeButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.ActualTheme == ElementTheme.Light)
            {
                this.RequestedTheme = ElementTheme.Dark;

            }
            else
            {
                this.RequestedTheme = ElementTheme.Light;

            }
        }

    }
}
